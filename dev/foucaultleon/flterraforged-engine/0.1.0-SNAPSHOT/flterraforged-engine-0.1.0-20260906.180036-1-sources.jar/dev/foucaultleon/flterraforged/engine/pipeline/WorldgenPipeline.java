package dev.foucaultleon.flterraforged.engine.pipeline;

import dev.foucaultleon.flterraforged.engine.EngineSettings;
import dev.foucaultleon.flterraforged.engine.api.EngineContext;
import dev.foucaultleon.flterraforged.engine.api.climate.ClimateSample;
import dev.foucaultleon.flterraforged.engine.api.river.RiverSample;
import dev.foucaultleon.flterraforged.engine.api.terrain.TerrainSample;
import dev.foucaultleon.flterraforged.engine.api.terrain.TerrainType;
import dev.foucaultleon.flterraforged.engine.cell.Cell;
import dev.foucaultleon.flterraforged.engine.cell.CellLookup;
import dev.foucaultleon.flterraforged.engine.climate.ClimateModel;
import dev.foucaultleon.flterraforged.engine.climate.ClimateRegionSampler;
import dev.foucaultleon.flterraforged.engine.climate.ClimateSettings;
import dev.foucaultleon.flterraforged.engine.continent.AdvancedContinent;
import dev.foucaultleon.flterraforged.engine.continent.Continent;
import dev.foucaultleon.flterraforged.engine.continent.ContinentSettings;
import dev.foucaultleon.flterraforged.engine.erosion.ErosionPipeline;
import dev.foucaultleon.flterraforged.engine.erosion.ErosionSettings;
import dev.foucaultleon.flterraforged.engine.internal.Maths;
import dev.foucaultleon.flterraforged.engine.noise.FractalNoise;
import dev.foucaultleon.flterraforged.engine.noise.GradientNoise;
import dev.foucaultleon.flterraforged.engine.noise.Interpolation;
import dev.foucaultleon.flterraforged.engine.noise.Noise;
import dev.foucaultleon.flterraforged.engine.noise.Noise2D;
import dev.foucaultleon.flterraforged.engine.noise.SeededNoise2D;
import dev.foucaultleon.flterraforged.engine.river.RiverModel;
import dev.foucaultleon.flterraforged.engine.river.RiverSettings;
import dev.foucaultleon.flterraforged.engine.terrain.TerrainClassificationSettings;
import dev.foucaultleon.flterraforged.engine.terrain.TerrainClassifier;
import dev.foucaultleon.flterraforged.engine.terrain.TerrainModel;
import dev.foucaultleon.flterraforged.engine.terrain.populator.TerrainPopulator;
import dev.foucaultleon.flterraforged.engine.terrain.provider.DefaultTerrainProvider;
import dev.foucaultleon.flterraforged.engine.terrain.provider.TerrainProvider;
import dev.foucaultleon.flterraforged.engine.terrain.region.TerrainRegionSampler;
import java.util.Objects;

/**
 * Fully assembled, immutable world-generation pipeline for one world seed.
 *
 * <p>The exact path guarantees the ordering
 * {@code continent -> terrain -> erosion -> climate-runoff -> river -> climate}. R49 additionally
 * retains the pre-erosion terrain/climate branch as a dedicated placement sampler so host structure
 * discovery cannot cold-start expensive local erosion or hydrology before visible chunk progress.
 * R51 makes sea level a hard hydrology invariant: coastal dry land is lifted through a narrow apron
 * and river mouths converge to the canonical world sea level before immutable samples are exposed.</p>
 */
public final class WorldgenPipeline implements CellLookup {

    private static final long CONTINENT_SEED = 0x27D4EB2F165667C5L;
    private static final long ROLLING_SEED = 0x9E3779B97F4A7C15L;
    private static final long RIDGE_SEED = 0x94D049BB133111EBL;
    private static final long DETAIL_SEED = 0xC2B2AE3D27D4EB4FL;
    private static final long TEMPERATURE_SEED = 0xD6E8FEB86659FD93L;
    private static final long MOISTURE_SEED = 0xA5A3564E27F3A21DL;
    private static final long TERRAIN_REGION_SEED = 0xDB4F0B9175AE2165L;
    private static final long EROSION_SEED = 0x165667B19E3779F9L;
    private static final long RIVER_SEED = 0x85EBCA77C2B2AE63L;
    private static final long CLIMATE_REGION_SEED = 0xC6BC279692B5C323L;

    private static final double MARINE_APRON_CONTINENTALNESS = 0.38D;
    private static final double RIVER_MOUTH_CONTINENTALNESS = 0.46D;
    private static final double MAXIMUM_MOUTH_WATER_OFFSET = 6.0D;
    private static final double MAXIMUM_MOUTH_DEPTH = 3.5D;
    private static final double MINIMUM_MOUTH_DEPTH = 1.25D;

    private final EngineContext context;
    private final TerrainModel terrain;
    private final RiverModel river;
    private final ClimateModel climate;
    private final ClimateModel placementClimate;
    private final TerrainClassificationSettings classificationSettings;
    private final TerrainClassifier classifier;

    /**
     * Creates and coordinates every world-generation stage for one world.
     *
     * @param context immutable world context
     * @param settings tuned engine settings
     */
    public WorldgenPipeline(EngineContext context, EngineSettings settings) {
        this.context = Objects.requireNonNull(context, "context");
        Objects.requireNonNull(settings, "settings");
        long seed = context.seed();

        Continent continent = new AdvancedContinent(seed ^ CONTINENT_SEED, ContinentSettings.from(settings));
        Noise2D rollingNoise = fractal(seed, ROLLING_SEED, settings.terrainScale(), 4, 0.52D, 2.02D);
        Noise2D ridgeNoise = fractal(seed, RIDGE_SEED, settings.terrainScale() * 0.78D, 5, 0.52D, 2.05D);
        Noise2D detailNoise = fractal(seed, DETAIL_SEED, settings.detailScale(), 3, 0.45D, 2.15D);

        TerrainRegionSampler terrainRegions = new TerrainRegionSampler(
                seed ^ TERRAIN_REGION_SEED,
                settings.terrainRegionScale(),
                settings.terrainRegionJitter());
        TerrainProvider terrainProvider = new DefaultTerrainProvider(
                rollingNoise,
                ridgeNoise,
                detailNoise,
                settings.relief(),
                settings.mountainRelief(),
                settings.terrainPlainsWeight(),
                settings.terrainHillsWeight(),
                settings.terrainValleyWeight(),
                settings.terrainPlateauWeight(),
                settings.terrainMountainWeight());
        TerrainPopulator baseTerrain = new TerrainPopulator(
                context,
                continent,
                terrainRegions,
                terrainProvider,
                settings.terrainBlendWidth());

        CellLookup baseLookup = (x, z, target) -> baseTerrain.populate(target, x, z);
        ErosionPipeline erosion = new ErosionPipeline(
                seed ^ EROSION_SEED,
                context,
                baseLookup,
                ErosionSettings.from(settings));

        ClimateSettings climateSettings = ClimateSettings.from(settings);
        ClimateRegionSampler climateRegions = new ClimateRegionSampler(
                seed ^ CLIMATE_REGION_SEED,
                climateSettings.regionScale(),
                climateSettings.regionJitter());
        Noise2D temperatureNoise = fractal(seed, TEMPERATURE_SEED, 1.0D, 3, 0.50D, 2.0D);
        Noise2D moistureNoise = fractal(seed, MOISTURE_SEED, 1.0D, 3, 0.50D, 2.0D);
        ClimateModel drainageClimate = new ClimateModel(
                context,
                baseLookup,
                temperatureNoise,
                moistureNoise,
                climateRegions,
                climateSettings);
        this.placementClimate = drainageClimate;

        this.river = new RiverModel(
                seed ^ RIVER_SEED,
                context,
                erosion,
                baseLookup,
                drainageClimate,
                RiverSettings.from(settings));
        this.terrain = new TerrainModel(context, river);
        this.climate = new ClimateModel(
                context,
                river,
                temperatureNoise,
                moistureNoise,
                climateRegions,
                climateSettings);
        this.classificationSettings = TerrainClassificationSettings.from(settings);
        this.classifier = new TerrainClassifier(classificationSettings);
    }

    /** {@inheritDoc} */
    @Override
    public void lookup(int x, int z, Cell target) {
        sampleCell(x, z, target);
    }

    /**
     * Samples all pipeline stages and final derived signals into a new cell.
     *
     * @param x world X coordinate
     * @param z world Z coordinate
     * @return fully populated cell
     */
    public Cell sampleCell(int x, int z) {
        return sampleCell(x, z, new Cell());
    }

    /**
     * Samples all pipeline stages and final derived signals into caller-owned storage.
     *
     * @param x world X coordinate
     * @param z world Z coordinate
     * @param target reusable target cell
     * @return {@code target}
     */
    public Cell sampleCell(int x, int z, Cell target) {
        Objects.requireNonNull(target, "target");
        climate.lookup(x, z, target);
        stabilizeWaterLevels(target);
        double west = stabilizedSurfaceHeight(x - 1, z);
        double east = stabilizedSurfaceHeight(x + 1, z);
        double north = stabilizedSurfaceHeight(x, z - 1);
        double south = stabilizedSurfaceHeight(x, z + 1);
        target.gradient = Math.hypot((east - west) * 0.5D, (south - north) * 0.5D);
        return target;
    }

    /**
     * Produces the stable Engine API sample for a world position.
     *
     * @param x world X coordinate
     * @param z world Z coordinate
     * @return completed terrain sample
     */
    public TerrainSample sample(int x, int z) {
        return toTerrainSample(sampleCell(x, z));
    }

    /**
     * Produces a low-cost deterministic sample for coarse host placement decisions.
     *
     * <p>This path executes continent, base terrain and climate only. It deliberately does not touch
     * erosion-region, river-map or lake caches. The semantic classifier still distinguishes broad
     * ocean, narrow coast and land so structure biome discovery remains useful.</p>
     *
     * @param x world X coordinate
     * @param z world Z coordinate
     * @return placement-stage terrain sample
     */
    public TerrainSample placementSample(int x, int z) {
        Cell cell = new Cell();
        placementClimate.lookup(x, z, cell);
        stabilizeWaterLevels(cell);
        double continentalness = cell.continentEdge * 2.0D - 1.0D;
        ClimateSample climateSample = new ClimateSample(cell.temperature, cell.moisture);
        TerrainType type = classifier.classify(
                cell.terrain,
                cell.height,
                context.seaLevel(),
                0.0D,
                continentalness,
                RiverSample.UNAVAILABLE);
        return new TerrainSample(
                cell.height,
                0.0D,
                0.0D,
                continentalness,
                type,
                climateSample,
                RiverSample.UNAVAILABLE);
    }

    /**
     * Generates one square tile of final samples while sharing the one-block gradient border.
     *
     * <p>A normal point sample needs four additional post-river height lookups to derive its local
     * gradient. Bulk generation instead evaluates a single one-block border around the tile and
     * reuses those completed cells for every interior gradient.</p>
     *
     * @param originX minimum world X coordinate of the tile
     * @param originZ minimum world Z coordinate of the tile
     * @param size tile width and depth in blocks
     * @return row-major immutable sample values represented by a new array
     */
    public TerrainSample[] sampleTile(int originX, int originZ, int size) {
        if (size < 1) {
            throw new IllegalArgumentException("size must be >= 1");
        }
        int stride = size + 2;
        Cell[] cells = new Cell[stride * stride];
        for (int dz = -1; dz <= size; dz++) {
            for (int dx = -1; dx <= size; dx++) {
                Cell cell = new Cell();
                climate.lookup(originX + dx, originZ + dz, cell);
                stabilizeWaterLevels(cell);
                cells[(dz + 1) * stride + (dx + 1)] = cell;
            }
        }

        TerrainSample[] samples = new TerrainSample[size * size];
        for (int localZ = 0; localZ < size; localZ++) {
            for (int localX = 0; localX < size; localX++) {
                int centerIndex = (localZ + 1) * stride + localX + 1;
                Cell center = cells[centerIndex];
                double west = cells[centerIndex - 1].height;
                double east = cells[centerIndex + 1].height;
                double north = cells[centerIndex - stride].height;
                double south = cells[centerIndex + stride].height;
                center.gradient = Math.hypot((east - west) * 0.5D, (south - north) * 0.5D);
                samples[localZ * size + localX] = toTerrainSample(center);
            }
        }
        return samples;
    }

    /**
     * Samples only the final post-river surface height without running climate.
     *
     * @param x world X coordinate
     * @param z world Z coordinate
     * @return final continuous surface height
     */
    public double surfaceHeight(int x, int z) {
        return stabilizedSurfaceHeight(x, z);
    }

    private double stabilizedSurfaceHeight(int x, int z) {
        Cell cell = terrain.sampleCell(x, z);
        stabilizeWaterLevels(cell);
        return cell.height;
    }

    private void stabilizeWaterLevels(Cell cell) {
        double continentalness = cell.continentEdge * 2.0D - 1.0D;
        double coast = classificationSettings.coastContinentalness();
        double seaLevel = context.seaLevel();
        boolean riverWater = Double.isFinite(cell.riverWaterSurfaceHeight);

        // River profiles remain free inland, but once a low river reaches the marine transition its
        // waterline is canonicalized to the same sea level used by the ocean materializer. This
        // prevents a several-block water shelf at the final river segment.
        if (riverWater
                && !cell.lake
                && continentalness <= coast + RIVER_MOUTH_CONTINENTALNESS
                && cell.riverWaterSurfaceHeight <= seaLevel + MAXIMUM_MOUTH_WATER_OFFSET) {
            double desiredDepth = Maths.clamp(
                    Math.max(cell.riverDepth, MINIMUM_MOUTH_DEPTH),
                    MINIMUM_MOUTH_DEPTH,
                    MAXIMUM_MOUTH_DEPTH);
            cell.riverWaterSurfaceHeight = seaLevel;
            cell.height = Math.min(cell.height, seaLevel - desiredDepth);
            cell.riverDepth = Math.max(0.0D, seaLevel - cell.height);
        }

        // The dry side of a shoreline may not remain several blocks below the adjacent global ocean
        // surface. Lift only a narrow continentalness apron; the dry COAST semantic itself stays
        // narrow and the change therefore removes vertical water walls without reintroducing huge
        // beach biomes.
        if (!cell.lake
                && !Double.isFinite(cell.riverWaterSurfaceHeight)
                && continentalness >= coast
                && continentalness <= coast + MARINE_APRON_CONTINENTALNESS
                && cell.height < seaLevel + 0.05D) {
            double alpha = Maths.smooth(Maths.clamp(
                    (continentalness - coast) / MARINE_APRON_CONTINENTALNESS,
                    0.0D,
                    1.0D));
            double minimumDryHeight = seaLevel + 0.10D + alpha * 1.65D;
            cell.height = Math.max(cell.height, minimumDryHeight);
        }
    }

    private TerrainSample toTerrainSample(Cell center) {
        double continentalness = center.continentEdge * 2.0D - 1.0D;
        ClimateSample climateSample = new ClimateSample(center.temperature, center.moisture);
        RiverSample riverSample = new RiverSample(
                center.riverDistance,
                center.riverWidth,
                center.riverDepth,
                center.riverWaterSurfaceHeight,
                center.riverFlow);
        TerrainType type = classifier.classify(
                center.terrain,
                center.height,
                context.seaLevel(),
                center.gradient,
                continentalness,
                riverSample,
                center.lake,
                center.lakeShore);
        return new TerrainSample(
                center.height,
                center.gradient,
                center.erosion,
                continentalness,
                type,
                climateSample,
                riverSample);
    }

    /**
     * Returns the immutable world context used by this pipeline.
     *
     * @return world context
     */
    public EngineContext context() {
        return context;
    }

    private static Noise2D fractal(
            long worldSeed,
            long seedOffset,
            double frequency,
            int octaves,
            double gain,
            double lacunarity) {
        Noise source = new GradientNoise(seedOffset, frequency, Interpolation.QUINTIC);
        return new SeededNoise2D(new FractalNoise(source, octaves, gain, lacunarity), worldSeed);
    }
}
