package dev.foucaultleon.flterraforged.engine;

import dev.foucaultleon.flterraforged.engine.api.EngineContext;
import dev.foucaultleon.flterraforged.engine.api.TerrainWorld;
import dev.foucaultleon.flterraforged.engine.api.chunk.ChunkSnapshot;
import dev.foucaultleon.flterraforged.engine.api.terrain.TerrainSample;
import dev.foucaultleon.flterraforged.engine.chunk.ChunkSnapshotCache;
import dev.foucaultleon.flterraforged.engine.pipeline.WorldgenPipeline;
import java.util.Objects;

/** Seed-bound deterministic world with shared terrain and complete natural-chunk caches. */
public final class DefaultTerrainWorld implements TerrainWorld {

    private final EngineContext context;
    private final WorldgenPipeline pipeline;
    private final WorldSampleCache sampleCache;
    private final ChunkSnapshotCache chunkCache;

    /**
     * Creates a deterministic terrain view for one world.
     *
     * @param context immutable world context
     * @param settings immutable engine settings
     */
    public DefaultTerrainWorld(EngineContext context, EngineSettings settings) {
        this.context = Objects.requireNonNull(context, "context");
        this.pipeline = new WorldgenPipeline(context, Objects.requireNonNull(settings, "settings"));
        this.sampleCache = new WorldSampleCache(pipeline);
        this.chunkCache = new ChunkSnapshotCache(context, sampleCache::sample);
    }

    /** {@inheritDoc} */
    @Override
    public EngineContext context() {
        return context;
    }

    /** {@inheritDoc} */
    @Override
    public TerrainSample sample(int x, int z) {
        return sampleCache.sample(x, z);
    }

    /** {@inheritDoc} */
    @Override
    public ChunkSnapshot chunkSnapshot(int chunkX, int chunkZ) {
        return chunkCache.get(chunkX, chunkZ);
    }

    /** Releases world-scoped immutable caches. */
    @Override
    public void close() {
        chunkCache.clear();
        sampleCache.clear();
    }
}
